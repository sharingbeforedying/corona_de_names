function borrow(ctx, obj) {

  console.log("borrow", this.constructor.name, obj);

  // const notifyChange = (k) => {
  //   console.log("notifyChange", k);
  //   ctx.$changes.change(k);
  // };

  Object.entries(obj).forEach(([k, v], i) => {
    console.log("defineProperty", k);

    //copy property
    ctx.k = Object.assign({}, v);

    const nativeChangeFunc = v.$changes.change.bind(v.$changes);
    v.$changes.change = (fieldName, isDelete) => {
      console.log("$changes.change", fieldName, isDelete);
      nativeChangeFunc(fieldName, isDelete);
      // notifyChange(k);

      ctx.k.fieldName = v.fieldName;

      //copy field
      // const newValue = v.fieldName;
      // if(typeof newValue === 'object' && newValue !== null) {
      //   Object.assign();
      // } else {
      //
      // }

    }

    // ctx.k = v;
    // Object.defineProperty(ctx, k, {
    //   get: function() {
    //     return v;
    //   },
    //   // set: function(value) {
    //   //
    //   // }
    // });

  });
}
exports.borrow = borrow;


function borrow2(obj) {

  return function() {
    console.log("borrow2", this.constructor.name, obj);

    // const notifyChange = (k) => {
    //   console.log("notifyChange", k);
    //   ctx.$changes.change(k);
    // };

    Object.entries(obj).forEach(([k, v], i) => {
      console.log("defineProperty", k);

      //copy property
      // const newV = new v.constructor();
      // this.k = Object.assign(newV, v);
      const deepCopy = JSON.parse(JSON.stringify(v));
      console.log("deepCopy", JSON.stringify(deepCopy));
      this.k = deepCopy;
      Object.defineProperty(ctx, k, {
        get: function() {
          return v;
        },
        // set: function(value) {
        //
        // }
      });

      const nativeChangeFunc = v.$changes.change.bind(v.$changes);
      v.$changes.change = (fieldName, isDelete) => {
        console.log("$changes.change", fieldName, isDelete);
        nativeChangeFunc(fieldName, isDelete);
        // notifyChange(k);

        console.log("this", this);
        this.k.fieldName = v.fieldName;

        //copy field
        // const newValue = v.fieldName;
        // if(typeof newValue === 'object' && newValue !== null) {
        //   Object.assign();
        // } else {
        //
        // }

      }

    });
  };

}
exports.borrow2 = borrow2;

















//
