(function() {
  exports.Gemini_Object = {};

  const createGemini = require("./GeminiHatch.js").createGemini;

  function fieldsFunc(obj) {
    var fields = null;
    if(obj instanceof Object) {
      fields = Object.fromEntries(Object.keys(obj)
                                        .filter(key => !key.startsWith("_"))
                                        .map(key => [key, typeof obj[key]])
                                        .filter(([fieldName, type]) => {
                                            const allowedTypes = ['string', 'number', 'object'];
                                            return allowedTypes.includes(type);
                                         })
                                 );
    }
    return fields;
  }
  exports.Gemini_Object.fieldsFunc = fieldsFunc;

  function createGemini_Object(target) {

    const name = target.constructor.name;
    return createGemini(name, target, fieldsFunc);
  }
  exports.Gemini_Object.create = createGemini_Object;

})();
