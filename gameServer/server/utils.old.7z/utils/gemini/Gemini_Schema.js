(function() {
  exports.Gemini_Schema = {};

  const createGemini = require("./GeminiHatch.js").createGemini;

  const schema    = require('@colyseus/schema');
  const Schema    = schema.Schema;

  function fieldsFunc(obj) {
    var fields = null;
    if(obj instanceof Schema) {
      fields = obj._schema;
    }
    return fields;
  }
  exports.Gemini_Schema.fieldsFunc = fieldsFunc;

  function createGemini_Schema(target) {

    const name = target.constructor.name;
    const gemini = createGemini(name, target, fieldsFunc);

    //report changes
    target.$onGeminiChange = (fieldName, isDelete) => {
      console.log("target, $onGeminiChange", fieldName);
      target.$changes.change(fieldName, isDelete);
    };

    gemini.$onGeminiChange = (fieldName, isDelete) => {
      console.log("gemini, $onGeminiChange", fieldName);
      gemini.$changes.change(fieldName, isDelete);
    };

    return gemini;
  }
  exports.Gemini_Schema.create = createGemini_Schema;

})();
