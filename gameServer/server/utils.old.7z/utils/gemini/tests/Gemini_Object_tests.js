(function() {
  exports.Gemini_Object = {};

  const testGemini = require("./Gemini_tests.js").testGemini;

  const fieldsFunc   = require("../Gemini_Object.js").Gemini_Object.fieldsFunc;
  const createGemini = require("../Gemini_Object.js").Gemini_Object.create;

  function testGemini_Object () {

    function equalsFunc(obj1, obj2) {
      var same = true;

      const schema1 = fieldsFunc(obj1);
      const schema2 = fieldsFunc(obj2);

      const schema1_length = Object.keys(schema1).length;
      const schema2_length = Object.keys(schema2).length;

      if(schema1_length == schema2_length) {
        for (var field in schema1) {
          const type1  = schema1[field];
          const value1 = obj1[field];

          const type2  = schema2[field];
          const value2 = obj2[field];

          const sameType  = (type1 == type2)
          if(!sameType) {
            same = false;
            console.log(field, "different type:", type1, "vs", type2);
            break;
          }

          var sameValue;
          if(value1 != null && value2 != null) {
            if(fieldsFunc(value1) != null) {
              sameValue = equalsFunc(value1,value2);
            } else {
              sameValue = value1 == value2;
            }
          } else {
            sameValue = value1 == value2;
          }
          if(!sameValue) {
            same = false;
            console.log(field , "different value:", value1, "vs", value2);
            break;
          }
        }
      } else {
        console.log("different lengths:", schema1_length, "vs", schema2_length);
        same = false;
      }

      return same;
    }

    class ClassB {
      constructor (str,nb) {
          // super();
          this.strB = str;
          this.nbB  = nb;
      }
    }

    class ClassA {
      constructor (strA,nbA,strB,nbB) {
          // super();
          this.strA = strA;
          this.nbA  = nbA;
          this.b    = new ClassB(strB,nbB);
      }
    }




    const target = new ClassA("a",0,"b",1);
    const gemini = createGemini(target);
    console.log("target", JSON.stringify(target));
    console.log("gemini", JSON.stringify(gemini));
    try {
      testGemini(target, gemini, fieldsFunc, equalsFunc);
      console.log("testGemini_Class", "success");
    } catch(error) {
      console.log("testGemini_Class", "failed", error);
    }
  }
  exports.Gemini_Object.test = testGemini_Object;

})();
