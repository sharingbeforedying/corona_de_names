(function() {
  exports.Gemini_Schema = {};

  const testGemini = require("./Gemini_tests.js").Gemini.test;

  const schema    = require('@colyseus/schema');
  const Schema    = schema.Schema;

  const fieldsFunc   = require("../Gemini_Schema.js").Gemini_Schema.fieldsFunc;
  const createGemini = require("../Gemini_Schema.js").Gemini_Schema.create;

  function testGemini_Schema () {

    function fieldsFunc(obj) {
      var fields = null;
      if(obj instanceof Schema) {
        fields = obj._schema;
      }
      return fields;
    }

    function equalsFunc(obj1, obj2) {
      var same = true;

      const schema1 = fieldsFunc(obj1);
      const schema2 = fieldsFunc(obj2);

      const schema1_length = Object.keys(schema1).length;
      const schema2_length = Object.keys(schema2).length;

      if(schema1_length == schema2_length) {
        for (var field in schema1) {
          const type1  = schema1[field];
          const value1 = obj1[field];

          const type2  = schema2[field];
          const value2 = obj2[field];

          const sameType  = (type1 == type2)
          if(!sameType) {
            same = false;
            console.log(field, "different type:", type1, "vs", type2);
            break;
          }

          var sameValue;
          if(value1 != null && value2 != null) {
            if(fieldsFunc(value1) != null) {
              sameValue = equalsFunc(value1,value2);
            } else {
              sameValue = value1 == value2;
            }
          } else {
            sameValue = value1 == value2;
          }
          if(!sameValue) {
            same = false;
            console.log(field , "different value:", value1, "vs", value2);
            break;
          }
        }
      } else {
        console.log("different lengths:", schema1_length, "vs", schema2_length);
        same = false;
      }

      return same;
    }

    class SchemaB extends Schema {
      constructor (str,nb) {
          super();
          this.strB = str;
          this.nbB  = nb;
      }
    }
    schema.defineTypes(SchemaB, {
      strB        : "string",
      nbB         : "number",
    });

    class SchemaA extends Schema {
      constructor (strA,nbA,strB,nbB) {
          super();
          this.strA = strA;
          this.nbA  = nbA;
          this.b    = new SchemaB(strB,nbB);
      }
    }
    schema.defineTypes(SchemaA, {
      strA        : "string",
      nbA         : "number",
      b           : SchemaB,
    });

    const target = new SchemaA("a",0,"b",1);
    const gemini = createGemini(target);
    console.log("target", JSON.stringify(target));
    console.log("gemini", JSON.stringify(gemini));
    try {
      testGemini(target, gemini, fieldsFunc, equalsFunc);
      console.log("testGemini_Schema", "success");
    } catch(error) {
      console.log("testGemini_Schema", "failed", error);
    }
  }
  exports.Gemini_Schema.test = testGemini_Schema;

})();
