(function() {
  exports.Gemini = {};

  const sample = require("../../Sample.js").sample;

  function testGemini(target, gemini, fieldsFunc, equalsFunc) {

    function assert(condition, message) {
      if (!condition) {
          message = message || "Assertion failed";
          if (typeof Error !== "undefined") {
              throw new Error(message);
          }
          throw message; // Fallback
      }
    }

    function logObject(name, obj) {

      if(obj != null) {
        console.log(name, "{");

        for (var field in fieldsFunc(obj)) {
          const value = obj[field];
          if(value != null) {
            if (fieldsFunc(value) != null) {
                logObject(field, value);
            } else {
                console.log(field, value);
            }
          } else {
            console.log(field, "null");
          }
        }
        console.log("}");
      } else {
        console.log(name, "null");
      }
    }


    function testProp(target, gemini, propName) {

      const original = target[propName];

      gemini[propName] = sample(original);
      assert(equalsFunc(target, gemini), "error");

      target[propName] = sample(original);
      assert(equalsFunc(target, gemini), "error");

      target[propName] = null;
      assert(equalsFunc(target, gemini), "error");

      target[propName] = sample(original);
      assert(equalsFunc(target, gemini), "error");


      gemini[propName] = null;
      assert(equalsFunc(target, gemini), "error");

      gemini[propName] = sample(original);
      assert(equalsFunc(target, gemini), "error");

    }

    function getProp(obj, predicate) {
      const fields = fieldsFunc(obj);
      if(fields != null) {
        const fieldNamesArray = Object.keys(fields);
        const entries = fieldNamesArray.map(fieldName => [fieldName, obj[fieldName]]).filter(([fieldName, value]) => predicate(value));
        return entries.map(([fieldName, value]) => fieldName).find(e => true);
      } else {
        return null;
      }
    }

    function getFlatProp(obj) {
      return getProp(obj, (value) => fieldsFunc(value) == null);
    }

    function getDeepProp(obj) {
      return getProp(obj, (value) => fieldsFunc(value) != null);
    }

    function testLevel(target, gemini, level) {
      console.log("testLevel", level);

      const flatProp = getFlatProp(target);
      const deepProp = getDeepProp(target);

      if(flatProp != null) {
        testProp(target, gemini, flatProp);
      }
      if(deepProp != null) {
        testProp(target, gemini, deepProp);
        testLevel(target[deepProp], gemini[deepProp], level + 1);
      }

    }

    logObject("target", target);
    logObject("gemini", gemini);
    assert(equalsFunc(target, gemini), "error");

    testLevel(target, gemini, 0);

  }
  exports.Gemini.test = testGemini;

})();
