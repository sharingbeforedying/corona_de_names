(function() {
  exports.Computed_Schema = {};

  const Computed = require("./Computed.js").Computed;
  const computed     = Computed.computed;
  const FieldFormula = Computed.FieldFormula;

  const schema    = require('@colyseus/schema');
  const Schema    = schema.Schema;

  function computed_Schema(obj, fieldFormulas) {
    const changeFunc = obj.$changes.change.bind(obj.$changes);
    const changeFuncSetter = (changeFunc) => {obj.$changes.change = changeFunc.bind(obj.$changes);};

    computed(obj, changeFunc, changeFuncSetter, fieldFormulas);
  }

  exports.Computed_Schema.computed     = computed_Schema;
  exports.Computed_Schema.FieldFormula = FieldFormula;

})();
