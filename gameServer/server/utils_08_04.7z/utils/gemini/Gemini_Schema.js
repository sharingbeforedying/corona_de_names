(function() {
  exports.Gemini_Schema = {};

  const createGemini = require("./GeminiHatch.js").createGemini;

  const schema    = require('@colyseus/schema');
  const Schema    = schema.Schema;

  function fieldsFunc(obj) {
    var fields = null;
    if(obj instanceof Schema) {
      fields = obj._schema;
    }
    return fields;
  }
  exports.Gemini_Schema.fieldsFunc = fieldsFunc;

  function createGemini_Schema(target, isEcho, miniSel) {

    const name   = target.constructor.name;
    const gemini = createGemini(name, target, fieldsFunc, isEcho, miniSel);

    //report changes
    target.$onGeminiChange = (fieldName, isDelete) => {
      console.log("target, $onGeminiChange", fieldName);
      target.$changes.change(fieldName, isDelete);
    };

    gemini.$onGeminiChange = (fieldName, isDelete) => {
      console.log("gemini, $onGeminiChange", fieldName);
      gemini.$changes.change(fieldName, isDelete);
    };

    return gemini;
  }

  exports.Gemini_Schema.createGemini = (target) => createGemini_Schema(target, isEcho = false, miniSel = null);
  exports.Gemini_Schema.createEcho   = (target) => createGemini_Schema(target, isEcho = true,  miniSel = null);


})();
