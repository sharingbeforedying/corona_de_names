(function() {

exports.Plus = {};

function plusAssign(obj, changeFunc, plusSel) {
  // const miniFields = mini(fieldsFunc(src), miniSel);
  //
  // Object.keys(miniFields).forEach((miniFieldName, i) => {
  //   const subMiniSel = miniSel[miniFieldName];
  //   if(subMiniSel) {
  //     miniAssign(dst[miniFieldName], src[miniFieldName], fieldsFunc, subMiniSel);
  //   } else {
  //     dst[miniFieldName] = src[miniFieldName];
  //   }
  // });

}
exports.Plus.plusAssign = plusAssign;


})();
